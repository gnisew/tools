(function ( w, d ) {

	var _id = 0;
	var t = typeof PKLocale !== 'undefined' ? PKLocale.t : function(k){return k;};

	function PKSimpleModal ( config ) {
		var q = this;

		this.id = config.id ? config.id : (++_id);

		var el = d.createElement ('div');
		this.els = {
			toolbar:[],
			bottom:[]
		};
		el.className = 'pk_modal ' + (config.clss ? config.clss : '');

		q.el = el;

		var el_back = d.createElement ('div');
		el_back.className = 'pk_modal_back';
		this.el_back = el_back;

		var el_cont = d.createElement ('div');
		el_cont.className = 'pk_modal_cnt';
		this.el_cont = el_cont;

		var el_title = d.createElement ('div');
		el_title.className = 'pk_noselect pk_modal_title';
		el_title.innerHTML = '<span>'+ (config.title || '') +'</span>';
		el.appendChild ( el_title );
		this.el_title = el_title;

		var el_main = d.createElement ('div');
		el_main.className = 'pk_modal_main';
		el.appendChild ( el_main );
		this.el_body = el_main;

		var el_bottom = d.createElement ('div');
		el_bottom.className = 'pk_noselect pk_modal_bottom';

		var a_cancel = d.createElement ('a');
		a_cancel.innerHTML = t('loading.cancel').toUpperCase();
		a_cancel.className = 'pk_modal_cancel pk_modal_a_bottom';
		a_cancel.onclick = function () {
			q.Destroy ();
		};
		el_bottom.appendChild ( a_cancel );

		if (config.buttons && config.buttons.length > 0)
		{
			for (var i = 0; i < config.buttons.length; ++i)
			{
				var curr = config.buttons[i];

				if (!curr.title || !curr.callback) continue;
				var a_bottom = d.createElement ('a');
				a_bottom.innerHTML = curr.title;
				a_bottom.className = 'pk_modal_a_bottom ' + (curr.clss ? curr.clss : '');

				if (curr.callback)
				{
					(function ( callback ) {
						a_bottom.onclick = function () {
							callback ( q );
						};
					})( curr.callback );
				}
				q.els.bottom.push (a_bottom);
				el_bottom.appendChild ( a_bottom );
			}
		}
		el.appendChild ( el_bottom );

		if (config.toolbar && config.toolbar.length > 0)
		{
			for (var i = 0; i < config.toolbar.length; ++i)
			{
				var curr = config.toolbar[i];
				if (!curr.title || !curr.callback) continue;
				var a_link = d.createElement ('a');
				a_link.innerHTML = curr.title + (curr.tooltip ? '<span>' + curr.tooltip + '</span>' : '');
				a_link.className = 'pk_modal_a_top ' + (curr.clss ? curr.clss : '');
				el_title.appendChild ( a_link );

				if (curr.callback)
				{
					(function ( callback ) {
						a_link.onclick = function () {
							callback ( q, this );
						};
					})( curr.callback );
				}
				q.els.toolbar.push (a_link);
			}
		}

		this.ondestroy = config.ondestroy;
		if (config.body) q.el_body.innerHTML = config.body;
		if (config.onpreset) this.onpreset = config.onpreset;
		if (config.setup) config.setup ( this );
	};

	PKSimpleModal.prototype.Show = function () {

		this.el_back.appendChild ( this.el_cont );
		this.el_cont.appendChild ( this.el );

		d.body.appendChild ( this.el_back );

		return (this);
	};

	PKSimpleModal.prototype.Destroy = function () {

		if (this.ondestroy) {
			this.ondestroy ( this );
			this.ondestroy = null;
		}
		this.els = null;
		d.body.removeChild ( this.el_back );
	};

	function PKAudioFXModal ( config, app ) {
		var toolbar = null;

		if (config.preview)
		{
			toolbar = [
				{
					title:PKLocale.t('ui.on'),
					clss:'pk_inact',
					tooltip:PKLocale.t('ui.toggle_bypass') + ' (B)',
					callback: function ( q, el ) {
						app.fireEvent ('RequestActionFX_TOGGLE');
					}
				},
				{
					title:PKLocale.t('ui.preview'),
					callback: function ( q ) {
						config.preview && config.preview ( q );
					}
				}
			];
		}

		var inner_modal = new PKSimpleModal({
			id: config.id,
			title: config.title,
			clss: config.clss,
			presets: config.presets,
			updateFilter: config.updateFilter,
			ondestroy: function ( q ) {

				app.fireEvent ('DidCloseFX_UI');

				app.stopListeningFor ('DidStartPreview',  q._evstart);
				app.stopListeningFor ('DidStopPreview',   q._evstop);
				app.stopListeningFor ('DidTogglePreview', q._evtoggle);
				app.stopListeningFor ('DidSetPresets', q._updatePresets);
				app.stopListeningFor ('RequestActionFX_UPDATE_PREVIEW',  q._updpreview);
				app.stopListeningFor ('RequestSetPresetActive',  q._updpreset);
				if (q._upd_t) {
					w.clearTimeout ( q._upd_t );
					q._upd_t = 0;
				}

				app.fireEvent ('RequestActionFX_PREVIEW_STOP');

				app.ui.KeyHandler.removeCallback ('ksp' + q.id);
				app.ui.KeyHandler.removeCallback ('kab' + q.id);

				config.ondestroy && config.ondestroy ( q );
			},
			toolbar: toolbar,
			buttons: config.buttons,
			body: config.body,
			onpreset: config.onpreset,
			setup:function( q ) {
				app.fireEvent ('RequestActionFX_TOGGLE', 1);

				var slf = this;
				app.ui.KeyHandler.addCallback ('ksp' + q.id, function ( key, map ) {
					if (!app.ui.InteractionHandler.check ('modalfx')) return ;

					var tb = slf.toolbar;
					if (tb && tb.length > 0)
					{
						var k = tb.length;
						while (k-- > 0) {
							if (tb[k].title === PKLocale.t('ui.preview')) {
								tb[k].callback ( q );
								break;
							}
						}
					}
				}, [32]);

				/* 新增：B 鍵切換 A/B（原音 ↔ 處理後），僅在預覽播放中有效 */
				app.ui.KeyHandler.addCallback ('kab' + q.id, function ( key, map, e ) {
					if (!app.ui.InteractionHandler.check ('modalfx')) return ;
					var tg = e && e.target;
					if (tg && (tg.tagName === 'TEXTAREA' || tg.tagName === 'SELECT' ||
						(tg.tagName === 'INPUT' && /^(text|number|search)$/.test (tg.type)))) return ;
					var btn = q.els && q.els.toolbar[0];
					if (!btn || btn.classList.contains ('pk_inact')) return ;
					app.fireEvent ('RequestActionFX_TOGGLE');
				}, [66]);

			  q._evstart = function () {
				  q.els.toolbar[0].classList.remove ('pk_inact');
				  q.els.toolbar[1].classList.add ('pk_act');
			  };
			  q._evstop = function () {
				  q.els.toolbar[0].classList.add ('pk_inact');
				  q.els.toolbar[1].classList.remove ('pk_act');
			  }

			  q._evtoggle = function ( val ) {
				  var el = q.els.toolbar[0];
				  el.firstChild.nodeValue = val ? PKLocale.t('ui.on') : PKLocale.t('ui.off');
			  };

				  q._updpreview = function ( val ) {
						var sel_opt = q.el_presets.options[q.el_presets.selectedIndex];
						var btn = q.el.getElementsByClassName('pk_sel_edt')[0];

						if (val === 't')
						{
							if (q._upd_t) w.clearTimeout ( q._upd_t );
							q._upd_t = 0;
							if (sel_opt && sel_opt.getAttribute('data-custom')) {
								btn.style.visibility = 'visible';
								btn.style.opacity = '1';
								app.stopListeningFor ('RequestActionFX_UPDATE_PREVIEW',  q._updpreview);
							}
							else
							{
								btn.style.visibility = 'hidden';
								btn.style.opacity = '0';
								app.stopListeningFor ('RequestActionFX_UPDATE_PREVIEW',  q._updpreview);
								q._upd_t = w.setTimeout(function (){
									q._upd_t = 0;
									app.listenFor ('RequestActionFX_UPDATE_PREVIEW',  q._updpreview);
								}, 100);
							}
							return ;
						}

						btn.style.visibility = 'visible';
						btn.style.opacity = '1';
						app.stopListeningFor ('RequestActionFX_UPDATE_PREVIEW',  q._updpreview);
				  };

			  q._updpreset = function ( fx_id, preset_id ) {
			  	  if (fx_id && fx_id !== q.id) {
			  	  	return ;
			  	  }

		  		  var opts = q.el_presets.getElementsByTagName('option');
		  		  var ll = opts.length;
		  		  var curr = null;

		  		  while (ll-- > 0) {
		  		  	curr = opts[ll];

		  		  	if (curr.getAttribute('data-custom') === preset_id) {
		  		  		curr.selected = 'selected';
		  		  		break;
		  		  	}
		  		  }
			  };

			  q._updatePresets = function ( fx_id, presets ) {
			  	  if (fx_id && fx_id !== q.id) {
			  	  	return ;
			  	  }

				  var d = document;
				  var sel_presets = q.el.getElementsByClassName ('pk_sel');

				  if (sel_presets.length > 0)
				  {
				  		  sel_presets = sel_presets[0];
				  		  var opts = sel_presets.getElementsByTagName('option');
				  		  var ll = opts.length;
				  		  var curr = null;

				  		  while (ll-- > 0) {
				  		  	curr = opts[ll];

				  		  	if (curr.getAttribute('data-custom')) {
				  		  		sel_presets.removeChild( curr );
				  		  	}
				  		  }

				  		  if (presets.length === 0) return ;

							var opt = d.createElement ('option');

							opt.setAttribute ('disabled', '1');
							opt.setAttribute ('data-custom', '1');
							opt.innerHTML = '---- ' + PKLocale.t('eq.custom') + ' ----';
							sel_presets.appendChild( opt );

						  for (var i = 0; i < presets.length; ++i)
						  {
							var opt = d.createElement ('option');
							var curr = presets[ i ];
							opt.value = curr.val;
							opt.setAttribute ('data-custom', curr.id);
							opt.innerHTML = app.escapeHtml ( app.unescapeHtml ( curr.name ) );
							sel_presets.appendChild( opt );
						  }

				  		  return ;
				  }
				  else
				  {
				  		sel_presets = d.createElement ('select');
				  		sel_presets.className = 'pk_sel';
				  }

				  if (presets.length === 0) return ;

				  for (var i = -1; i < presets.length; ++i)
				  {
					var opt = d.createElement ('option');

					if (i === -1)
					{
						opt.value = 'null';
						opt.innerHTML = t('eq.preset');
					}
					else
					{
						var curr = presets[ i ];
						opt.value = curr.val;
						var pk = 'preset.' + app.unescapeHtml ( curr.name );
						var pn = t(pk);
						opt.innerHTML = app.escapeHtml ( pn !== pk ? pn : app.unescapeHtml ( curr.name ) );
					}
					sel_presets.appendChild( opt );
				  }

				  sel_presets.onchange = function () {
					  var val_arr = this.value.split(',');
					  var els = q.el.getElementsByTagName('input');

					  q._updpreview ('t');

					  if (q.onpreset)
					  {
					  	q.onpreset (this.value);
					  	return ;
					  }

					  var len = els.length;

					  for (var i = 0; i < len; ++i) {
						  if (!val_arr[ i ]) break;

						  var curr_val = val_arr[ i ].trim ();
						  var curr_input = els[ i ];

						  if (curr_val === 'null') continue;

						  if (curr_input.type === 'checkbox' || curr_input.type === 'radio')
							curr_input.checked = curr_val;
						  else
						  {
							curr_input.value = curr_val;
							curr_input.oninput && curr_input.oninput.apply (curr_input);
						  }
					  }
				  };
				  var btm = q.el.getElementsByClassName('pk_modal_bottom')[0];

				  btm.appendChild ( sel_presets );
				  q.el_presets = sel_presets;

				  var edit_presets = d.createElement ('a');
				  edit_presets.className = 'pk_sel_edt';
				  edit_presets.innerHTML = '...<span>' + PKLocale.t('ui.save_or_modify') + '</span>';
				  edit_presets.onclick = function () {
				  	app.fireEvent ('RequestSavePreset');
				  };

				  btm.appendChild ( edit_presets );
				  app.listenFor ('RequestActionFX_UPDATE_PREVIEW',  q._updpreview);
				  app.listenFor ('RequestSetPresetActive',  q._updpreset);
			  };

			  app.listenFor ('DidStartPreview',  q._evstart);
			  app.listenFor ('DidStopPreview',   q._evstop);
			  app.listenFor ('DidTogglePreview', q._evtoggle);
			  app.fireEvent ('DidOpenFX_UI', q);

			  if (config.updateFilter) q.updateFilter = config.updateFilter;

			  if (config.presets)
			  {
			  	q._updatePresets (null, config.presets);
			  	if (config.custom_pres) q._updatePresets (null, config.custom_pres);

				app.listenFor ('DidSetPresets', q._updatePresets);
			  }

			  config.setup && config.setup ( q );
			}
		});

		return (inner_modal);
	};

	w.PKSimpleModal = PKSimpleModal;
	w.PKAudioFXModal = PKAudioFXModal;
})( window, document );


